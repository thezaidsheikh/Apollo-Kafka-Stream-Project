"use strict";

module.exports = (app, router) => {
  require("../routes/source.routes")(app, router);
};
