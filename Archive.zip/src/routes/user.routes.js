"use strict";

const userController = require("../controller/user.controller");

module.exports = (app, router) => {};
