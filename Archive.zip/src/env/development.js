"use strict";

module.exports = {
  PORT: 2022,
  BASE_URL: `mongodb://localhost:27017/appolo-stream`,
};
