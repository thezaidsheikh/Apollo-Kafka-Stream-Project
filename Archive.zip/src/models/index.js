module.exports = {
  source_time: require("../models/source_time.model"),
  source_log: require("../models/source_log.model"),
  source_parameter: require("../models/source_parameter.model"),
  source_depth: require("../models/source_depth.model"),
};
